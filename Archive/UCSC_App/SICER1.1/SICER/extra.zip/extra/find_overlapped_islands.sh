#!/bin/bash
PATHTO=/home/data/SICER1.1
SICER=$PATHTO/SICER
PYTHONPATH=$SICER/lib
export PYTHONPATH


find_overlapped_islands.py