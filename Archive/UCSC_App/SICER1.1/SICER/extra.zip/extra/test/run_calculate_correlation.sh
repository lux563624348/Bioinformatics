#!/bin/bash


sh calculate_correlation.sh /home/data/hg18/CD36/nucleosome CD36-shBrg1-5-nucs-chr1
sh calculate_correlation.sh /home/data/hg18/CD36/nucleosome CD36-shLuc-nucs-chr1


#sh calculate_correlation.sh /home/data/hg18/CD4/processed H3K9me2-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD4/processed H3K9me3-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD4/processed H4K20me3-1-removed
echo ""
echo ""
echo ""
echo ""
#sh calculate_correlation.sh /home/data/hg18/CD4 H3K27me3
echo ""
echo ""
echo ""
echo ""
#sh calculate_correlation.sh /home/data/hg18/CD8/2010data/processed 0h_EM_K27-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD8/2010data/processed 0h_N_K27-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD8/2010data/processed 72h_EM_EZh2-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD8/processed TEM72_H3K9ac-1-removed
#sh calculate_correlation.sh /home/data/hg18/CD8/processed TEM72_H3K4me3-1-removed
echo ""
echo ""
echo ""
echo ""
#sh calculate_correlation.sh /home/data/hg18/CD8/2010data/processed 72h_EM_K27-1-removed
echo ""
echo ""
echo ""
echo ""
#sh calculate_correlation.sh /home/data/hg18/CD8/2010data/raw 72h_EM_K27