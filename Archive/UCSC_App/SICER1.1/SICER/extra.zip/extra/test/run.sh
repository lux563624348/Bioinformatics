sh GenerateProfileAroundLocations.sh > GenerateProfileAroundLocations.sh.log 

sh GenerateProfileMatrixAroundLocations.sh > GenerateProfileMatrixAroundLocations.sh.head100.log 