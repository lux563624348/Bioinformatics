#\!/bin/bash
sh bowtie2.sh index5 /home/wpeng/Downloads/bowtie_annotation mm9