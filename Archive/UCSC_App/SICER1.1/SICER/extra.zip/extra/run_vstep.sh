#!/bin/sh

sh variableStep.sh ../$1-islandfiltered.graph $1.vstep $2